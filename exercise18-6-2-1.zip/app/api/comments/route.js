import connectToDatabase from "@/app/lib/db"
import { NextResponse } from "next/server";
import Comment from "@/models/Comment";
import Product from "@/models/Product";
import User from "@/models/User";

export const GET = async (params) => {
    try {
        await connectToDatabase();
        const comments = await Comment.find().populate({ path: 'userId', model: User }).populate({ path: 'productId', model: Product });
        return new NextResponse(JSON.stringify(comments), {status: 200});
    } catch (error) {
        return new NextResponse('خطا در اتصال به دیتابیس', {status: 500});
    }
}